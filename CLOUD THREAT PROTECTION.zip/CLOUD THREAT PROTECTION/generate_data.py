import pandas as pd
import random
import os
import string
from src.processor.feature_engineer import FeatureEngineer
from src.config import settings

def generate_random_string(length):
    return ''.join(random.choices(string.ascii_letters + string.digits + "!@#$%^&*", k=length))

def generate_synthetic_data(num_samples=1000):
    """
    Generates realistic synthetic log data with advanced features.
    """
    print(f"Generating {num_samples} samples of hardened IDPS dataset...")
    
    data = []
    
    patterns = {
        "normal": [
            "User login success", "DB Query ok", "Health check pulse", "File sync finish"
        ],
        "attack": [
            "Failed login attempt", "Unauthorized API access", "SQL Exploit detected", "Malicious overflow"
        ]
    }

    for _ in range(num_samples):
        is_malicious = random.random() > 0.85 
        
        if is_malicious:
            log_line = random.choice(patterns["attack"]) + " " + generate_random_string(random.randint(20, 100))
            label = 1
        else:
            log_line = random.choice(patterns["normal"]) + " " + random.choice(["user1", "app_v2", "node_5"])
            label = 0
            
        features = FeatureEngineer.extract_features(log_line)
        features['label'] = label # Labels still useful for generate data, though training is unsupervised
        data.append(features)

    os.makedirs(os.path.dirname(settings.DATA_PATH), exist_ok=True)
    pd.DataFrame(data).to_csv(settings.DATA_PATH, index=False)
    print(f"Hardened dataset saved to {settings.DATA_PATH}")

if __name__ == "__main__":
    generate_synthetic_data()
