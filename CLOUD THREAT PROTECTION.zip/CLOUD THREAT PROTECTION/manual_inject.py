import time
import os
import random
from src.config import settings

LOG_FILE = settings.LOG_FILE_PATH

def inject(log_line):
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, 'a') as f:
        f.write(f"{log_line}\n")
    print(f" >>> [LOG WRITTEN]: {log_line}")

def show_menu():
    print("\n" + "="*40)
    print("   AI IDPS MANUAL TESTING HELPER   ")
    print("="*40)
    print("1. Normal Traffic (Baseline)")
    print("2. Known Attack (Signature)")
    print("3. Unauthorized Access (Logic)")
    print("4. Zero-Day Attack (Anomaly)")
    print("5. Mixed Traffic (Bulk Stress)")
    print("6. Exit")
    print("="*40)

def main():
    while True:
        show_menu()
        choice = input("Enter Choice (1-6): ")
        
        if choice == '1':
            inject("User accessed homepage /index.html from 192.168.1.5")
            print("Expected: NO ALERT in logs/alerts.log")
            
        elif choice == '2':
            inject("Failed login attempt for user 'admin' from 10.0.0.50")
            print("Expected: RULE DETECTION ALERT (Signature match)")
            
        elif choice == '3':
            inject("Unauthorized access detected on confidential /api/admin")
            print("Expected: RULE or AI DETECTION (High-risk keywords)")
            
        elif choice == '4':
            # Create a very strange, long, high-entropy string
            anomaly = "CRITICAL: " + "X" * 200 + " !! EXPLOIT !! " + "0x" + "FF"*20
            inject(anomaly)
            print("Expected: AI ANOMALY ALERT (Isolation Forest score)")
            
        elif choice == '5':
            print("Injecting 50 mixed logs rapidly...")
            for i in range(50):
                if random.random() > 0.9:
                    inject(f"ATTACK log entry #{i} - malware call detected")
                else:
                    inject(f"Normal background noise entry #{i}")
            print("Expected: Only malicious logs should trigger alerts.")
            
        elif choice == '6':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
