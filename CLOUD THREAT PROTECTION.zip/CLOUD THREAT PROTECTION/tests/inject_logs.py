import time
import os
import random
from src.config import settings

def inject(log_line, count=1):
    os.makedirs(os.path.dirname(settings.LOG_FILE_PATH), exist_ok=True)
    with open(settings.LOG_FILE_PATH, 'a') as f:
        for _ in range(count):
            f.write(f"{log_line}\n")
    print(f"[Injected x{count}] {log_line[:60]}...")

def run_suite():
    print("--- INDUSTRY-GRADE INJECTION SUITE STARTING ---")
    
    # Phase A: Baseline (No Alerts Expected)
    print("\n[PHASE A] Baseline Traffic")
    normal_msgs = [
        "User log-in successful",
        "API health check: 200 OK",
        "Data sync completed successfully"
    ]
    for msg in normal_msgs:
        inject(msg)
        time.sleep(0.5)

    # Phase B: Signature Attacks (Rules should catch)
    print("\n[PHASE B] Signature Attacks")
    inject("Failed login attempt for admin from 10.0.0.5")
    inject("Unauthorized access to /etc/passwd")

    # Phase C: Zero-Day / Anomaly (AI should catch)
    print("\n[PHASE C] Zero-Day Anomalies")
    # Buffer overflow/Strange pattern
    inject("X" * 300 + " !! EXPLOIT_PAYLOAD !! " + "X" * 100)
    # Rare keyword pattern
    inject("Remote memory address corruption attempt detected")

    # Phase D: Stress Test
    print("\n[PHASE D] Stress Test (100 logs rapid-fire)")
    for i in range(100):
        inject(f"Stress test log entry #{i}", count=1)
        # No sleep to test throughput

    print("\n--- INJECTION COMPLETE ---")

if __name__ == "__main__":
    run_suite()
