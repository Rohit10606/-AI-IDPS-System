import os
import sys

# --- ROBUST PATH INJECTION ---
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
# -----------------------------

from src.detector.rules import RuleEngine
from src.detector.ai_engine import AIEngine
from src.utils.logger import setup_logger

def test_engines():
    logger = setup_logger('TestEngines', 'logs/test.log')
    print("Testing Detection Engines...")
    
    # 1. Rule Engine Test
    rules = RuleEngine(logger)
    is_threat, reason = rules.check_log("Failed login attempt for admin")
    if is_threat and "Failed" in reason:
        print("[PASS] RuleEngine identified signature threat.")
    else:
        print(f"[FAIL] RuleEngine missed signature threat. Reason: {reason}")

    # 2. AI Engine Test
    ai = AIEngine(logger)
    if not ai.pipeline:
        print("[SKIP] AI Engine Test skipped (Pipeline not found). Run train_model.py first.")
    else:
        # Test Anomaly (High entropy string)
        anomaly_log = "X" * 300 + "!! exploit !!"
        is_threat, score = ai.predict(anomaly_log)
        if is_threat:
            print(f"[PASS] AIEngine detected anomaly (Score: {score:.4f}).")
        else:
            print(f"[FAIL] AIEngine missed anomaly. Score: {score:.4f}")

if __name__ == "__main__":
    test_engines()
