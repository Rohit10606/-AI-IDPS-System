from src.response.action import Responder
from src.notifier.alerter import Alerter
from src.utils.logger import setup_logger
import os

def test_response():
    logger = setup_logger('TestResponse', 'logs/test.log')
    print("Testing Response & Notification...")
    
    # 1. Alerter Test
    alerter = Alerter(logger)
    alert_path = "logs/test_alerts.log"
    if os.path.exists(alert_path): os.remove(alert_path)
    
    alerter.alert_log = alert_path # Redirect for testing
    alerter.send_alert("Unit Test Threat", "Tester", "Details 123")
    
    if os.path.exists(alert_path):
        print("[PASS] Alerter stored alert persistently.")
    else:
        print("[FAIL] Alerter failed to store alert.")

    # 2. Responder Test
    responder = Responder(logger)
    log = "Malicious entry from 1.2.3.4"
    
    # Trigger mitigation should return true if IP is found
    success = responder.trigger_mitigation("Test", log)
    
    if success and "1.2.3.4" in responder.blocked_ips:
        print("[PASS] Responder correctly extracted and blocked IP.")
    else:
        print(f"[FAIL] Responder failed to block IP. State: {responder.blocked_ips}")

    # Safelist check
    safelist_log = "Malicious from 127.0.0.1"
    responder.trigger_mitigation("Test", safelist_log)
    if "127.0.0.1" not in responder.blocked_ips:
        print("[PASS] Responder correctly ignored safelisted IP.")
    else:
        print("[FAIL] Responder blocked a safelisted IP!")

if __name__ == "__main__":
    test_response()
