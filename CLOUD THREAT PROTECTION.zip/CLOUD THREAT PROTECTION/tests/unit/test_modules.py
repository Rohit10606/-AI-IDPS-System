import sys
import os
import unittest
from unittest.mock import MagicMock

# Add root to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.detector.rules import RuleEngine
from src.detector.ai_engine import AIEngine
from src.processor.feature_engineer import FeatureEngineer

class TestIDPSModules(unittest.TestCase):
    
    def setUp(self):
        self.mock_logger = MagicMock()
        self.rules = RuleEngine(self.mock_logger)
        self.ai = AIEngine(self.mock_logger)

    def test_rule_engine_failed_admin(self):
        # Case: Failed admin login
        match, reason = self.rules.check_log("Failed login for admin")
        self.assertTrue(match)
        self.assertIn("Suspicious: Failed Admin Login", reason)

    def test_rule_engine_unauthorized_attack(self):
        # Case: Unauthorized attack
        match, reason = self.rules.check_log("unauthorized activity and attack detected")
        self.assertTrue(match)
        self.assertIn("Critical: Unauthorized Attack Pattern", reason)

    def test_rule_engine_normal(self):
        # Case: Normal traffic
        match, reason = self.rules.check_log("User browsing homepage")
        self.assertFalse(match)

    def test_feature_extraction(self):
        log = "Normal traffic entry"
        features = FeatureEngineer.extract_features(log)
        self.assertEqual(features['length'], len(log))
        self.assertGreater(features['entropy'], 0)

    def test_ai_engine_inference_fallback(self):
        # Test AI engine call even if model missing (should return False)
        # Note: In our current setup, the model was trained, so it might load.
        # But we test the interface stability.
        is_threat, score = self.ai.predict("Normal log")
        self.assertIsInstance(is_threat, bool)
        self.assertIsInstance(score, float)

if __name__ == "__main__":
    unittest.main()
