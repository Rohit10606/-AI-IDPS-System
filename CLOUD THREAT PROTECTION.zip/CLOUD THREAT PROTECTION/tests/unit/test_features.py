from src.processor.feature_engineer import FeatureEngineer

def test_features():
    print("Testing FeatureEngineer...")
    
    # Sample malicious log
    log = "FAILED login attempt admin !! exploit !!"
    
    features = FeatureEngineer.extract_features(log)
    
    # Check for expected feature presence
    expected_keys = ['length', 'entropy', 'failed', 'unauthorized', 'attack', 'digit_density', 'special_density']
    
    missing = [k for k in expected_keys if k not in features]
    
    if not missing:
        print("[PASS] All expected features extracted.")
    else:
        print(f"[FAIL] Missing features: {missing}")

    # Specific logic check
    if features['failed'] == 1 and features['attack'] == 1:
        print("[PASS] Keyword flags correctly identified.")
    else:
        print(f"[FAIL] Keyword logic incorrect. Features: {features}")

    # Vector consistency
    vector = FeatureEngineer.log_to_vector(log)
    if len(vector) == len(expected_keys):
        print("[PASS] Feature vector length matches specification.")
    else:
        print(f"[FAIL] Vector length mismatch. Expected {len(expected_keys)}, got {len(vector)}")

if __name__ == "__main__":
    test_features()
