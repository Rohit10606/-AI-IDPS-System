import os
import time
from src.monitor.live_monitor import LiveMonitor
from src.utils.logger import setup_logger

def test_monitor():
    print("Testing LiveMonitor...")
    log_path = "logs/test_monitor.log"
    logger = setup_logger('TestMonitor', 'logs/test.log')
    
    # Ensure fresh start
    if os.path.exists(log_path): os.remove(log_path)
    
    monitor = LiveMonitor(log_path, logger)
    
    # Test 1: Appending a line
    with open(log_path, 'a') as f:
        f.write("Line 1\n")
    
    time.sleep(0.1) # Small delay for I/O
    new_logs = monitor.get_new_logs()
    
    if len(new_logs) == 1 and new_logs[0] == "Line 1":
        print("[PASS] Monitor detected new line.")
    else:
        print(f"[FAIL] Monitor failed. Found: {new_logs}")

    # Test 2: Reading only new lines
    with open(log_path, 'a') as f:
        f.write("Line 2\n")
    
    new_logs = monitor.get_new_logs()
    if len(new_logs) == 1 and new_logs[0] == "Line 2":
        print("[PASS] Monitor correctly skipped old lines.")
    else:
        print("[FAIL] Monitor re-read old data or missed new data.")

if __name__ == "__main__":
    test_monitor()
