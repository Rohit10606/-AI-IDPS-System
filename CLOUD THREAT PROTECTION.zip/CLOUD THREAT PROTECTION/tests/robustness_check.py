import os
import shutil
import time
from src.config import settings

def run_robustness_check():
    print("--- IDPS ROBUSTNESS & FALLBACK TEST ---")
    
    model_path = settings.MODEL_PATH
    temp_backup = model_path + ".bak"

    # 1. Simulate Missing Model
    if os.path.exists(model_path):
        print(f"Modifying system state: Moving model to {os.path.basename(temp_backup)}")
        shutil.move(model_path, temp_backup)
    
    print("Injecting threat while model is missing...")
    # This should be caught by Rules, even if AI is offline
    with open(settings.LOG_FILE_PATH, 'a') as f:
        f.write("Failed admin login - Fallback Test\n")
    
    time.sleep(2) # Wait for processing
    print("Verifying fallback detection...")
    
    # Verify alert exists
    found_alert = False
    if os.path.exists(settings.ALERT_LOG_PATH):
        with open(settings.ALERT_LOG_PATH, 'r') as f:
            if "Fallback Test" in f.read():
                found_alert = True
                print("[SUCCESS] Rule-Engine caught threat during AI downtime.")

    # 2. Restore System
    if os.path.exists(temp_backup):
        print(f"Restoring system state: Moving model back to {os.path.basename(model_path)}")
        shutil.move(temp_backup, model_path)
    
    if not found_alert:
        print("[FAILURE] System did not catch threat during AI downtime.")

if __name__ == "__main__":
    run_robustness_check()
