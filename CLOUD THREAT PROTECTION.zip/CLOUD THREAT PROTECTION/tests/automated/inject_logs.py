import time
import os
import random
from src.config import settings

# Mixed test data
TEST_LOGS = [
    ("User viewed profile /u/user123", False),  # Normal
    ("Database backup completed successfully", False),  # Normal
    ("Failed login attempt for user 'admin' from 1.2.3.4", True),  # Rule Match
    ("Unauthorized access attempt on /v1/api/internal", True),  # Rule/AI Match
    ("Normal health check request: 200 OK", False),  # Normal
    ("CRITICAL: !! EXPLOIT !! " + "A"*150 + " 0xDEADBEEF", True),  # AI Anomaly
    ("SQL Injection attempt detected in query string", True),  # Rule Match
    ("Regular session cleanup", False),  # Normal
]

LOG_FILE = settings.LOG_FILE_PATH
ALERT_LOG = settings.ALERT_LOG_PATH

def clear_logs():
    if os.path.exists(LOG_FILE):
        open(LOG_FILE, 'w').close()
    if os.path.exists(ALERT_LOG):
        open(ALERT_LOG, 'w').close()

def inject_log(line):
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    with open(LOG_FILE, 'a') as f:
        f.write(f"{line}\n")
    print(f" [INJECTED]: {line}")

def main():
    print("--- STARTING AUTOMATED LOG INJECTION TEST ---")
    clear_logs()
    
    total_injected = 0
    expected_alerts = 0
    
    # Inject 50 logs total, mixing the patterns
    for i in range(50):
        log_text, is_threat = random.choice(TEST_LOGS)
        full_log = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {log_text} (ID: {i})"
        inject_log(full_log)
        
        total_injected += 1
        if is_threat:
            expected_alerts += 1
        
        # Micro-sleep to simulate real-time traffic
        time.sleep(0.1)

    print("\n--- INJECTION COMPLETE ---")
    print(f"Total Injected: {total_injected}")
    print(f"Expected Threats: {expected_alerts}")
    print("Waiting for IDPS to catch up (5 seconds)...")
    time.sleep(5)
    
    # Simple validation count
    if os.path.exists(ALERT_LOG):
        with open(ALERT_LOG, 'r') as f:
            actual_alerts = len(f.readlines())
        print(f"Actual Alerts Recorded: {actual_alerts}")
        print(f"Detection Ratio: {(actual_alerts/expected_alerts)*100:.1f}%" if expected_alerts > 0 else "N/A")
    else:
        print("Error: No alerts.log found. Ensure src/main.py is running!")

if __name__ == "__main__":
    main()
