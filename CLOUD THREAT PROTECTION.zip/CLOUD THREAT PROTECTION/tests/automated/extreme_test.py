import threading
import time
import os
import random
from src.config import settings
from concurrent.futures import ThreadPoolExecutor

LOG_FILE = settings.LOG_FILE_PATH
ALERT_LOG = settings.ALERT_LOG_PATH

# Patterns for stress test
NORMAL_PATTERNS = [
    "User accessed asset /img/logo.png",
    "API heartbeat check source=monitoring-node",
    "Database session established",
    "File sync operation progress=45%",
    "Internal cron job executed: cleanup_tmp"
]

ATTACK_PATTERNS = [
    "Failed admin login attempt from 192.168.1.50",
    "SQLi string detected in parameter 'id'",
    "Unauthorized access attempt on secure endpoint /api/v1/vault",
    "MALICIOUS: Buffer overflow attempt detected",
    "ALERT: Abnormal traffic volume from single IP"
]

def inject_log():
    # Mix: 90% normal, 10% attack
    if random.random() > 0.9:
        line = random.choice(ATTACK_PATTERNS)
    else:
        line = random.choice(NORMAL_PATTERNS)
        
    full_line = f"[{time.strftime('%H:%M:%S')}] [STRESS-TEST] {line}"
    
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"{full_line}\n")

def worker(num_logs):
    for i in range(num_logs):
        inject_log()
        if i % 100 == 0:
            print(f" Thread {threading.current_thread().name} injected {i} logs...")

def main():
    print("--- STARTING EXTREME STRESS TEST ---")
    print("Goal: Inject 5000+ logs rapidly using multi-threading.")
    
    start_time = time.time()
    
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    # Clear system log for clean run
    open(LOG_FILE, 'w', encoding='utf-8').close()

    num_threads = 10
    logs_per_thread = 500
    
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        for i in range(num_threads):
            executor.submit(worker, logs_per_thread)

    end_time = time.time()
    duration = end_time - start_time
    total_logs = num_threads * logs_per_thread
    
    print("\n" + "="*40)
    print("   STRESS TEST RESULTS   ")
    print("="*40)
    print(f"Total Logs Injected: {total_logs}")
    print(f"Total Duration: {duration:.2f} seconds")
    print(f"Injection Rate: {total_logs / duration:.2f} logs/sec")
    print("="*40)
    print("Check IDPS terminal to ensure it is still running and processing logs.")

if __name__ == "__main__":
    main()
