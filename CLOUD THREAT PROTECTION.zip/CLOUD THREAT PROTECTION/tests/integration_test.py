import os
import sys

# --- ROBUST PATH INJECTION ---
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
# -----------------------------

import subprocess
import time
import signal

def run_integration_sequence():
    print("==========================================")
    print("   IDPS END-TO-END INTEGRATION TEST   ")
    print("==========================================")

    # Use absolute paths or handle current dir correctly
    log_path = os.path.join("logs", "system.log")
    alert_path = os.path.join("logs", "alerts.log")
    
    # 1. Start IDPS in background
    print("\n[1/4] Starting IDPS process...")
    # Add PYTHONPATH env to the subprocess
    env = os.environ.copy()
    env["PYTHONPATH"] = os.getcwd()
    
    idps = subprocess.Popen(["python", "src/main.py"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
    time.sleep(5) # Wait for initialization (Rich startup banner takes time)

    try:
        # 2. Inject Mixed Traffic
        print("[2/4] Injecting Mixed Traffic (Normal + Malicious)...")
        with open(log_path, 'a') as f:
            f.write("Normal heartbeat from testing service\n")
            f.write("Failed login attempt for root from 192.168.1.10\n")
            f.write("Unauthorized access on port 22 from 10.0.0.5\n")
        
        # Give it more time for detection processing
        print("      Wait for processing...")
        time.sleep(8) 

        # 3. Verify Chains
        print("[3/4] Verifying detection chain...")
        if os.path.exists(alert_path):
            with open(alert_path, 'r') as f:
                alerts = f.readlines()
            
            print(f"      - Total Alerts Found: {len(alerts)}")
            if len(alerts) >= 1:
                print("      - [PASS] Detection and alerting chain verified.")
            else:
                print("      - [FAIL] Expected at least 1 alert.")
        else:
            print("      - [FAIL] Alert log file missing.")

        # 4. Cleanup
        print("[4/4] Shutting down...")
        
    finally:
        # Cross-platform termination
        idps.terminate()
        try:
            idps.wait(timeout=5)
        except subprocess.TimeoutExpired:
            idps.kill()
    
    print("\nINTEGRATION TEST COMPLETE.")

if __name__ == "__main__":
    run_integration_sequence()
