import os
import sys

# --- ROBUST PATH INJECTION ---
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from src.notifier.alerter import Alerter
from src.storage.db_manager import DatabaseManager
from src.utils.logger import setup_logger
from src.config import settings

def test_enterprise_integration():
    logger = setup_logger('EnterpriseTest', 'logs/test_enterprise.log')
    print("Starting Enterprise Integration Test...")
    
    # 1. Initialize Components
    alerter = Alerter(logger)
    db = DatabaseManager()
    
    # 2. Simulate Alert
    print("Sending test alert...")
    alerter.send_alert(
        threat_type="Enterprise Test Threat",
        detected_by="Manual-Test",
        details="Verifying DB and Webhook integration.",
        severity="CRITICAL"
    )
    
    # 3. Verify Database Record
    print("Verifying Database record...")
    recent_alerts = db.get_recent_alerts(limit=5)
    
    found = False
    for alert in recent_alerts:
        if alert['threat_type'] == "Enterprise Test Threat":
            print(f"PASS: Alert found in DB (ID: {alert['id']})")
            found = True
            break
            
    if not found:
        print("FAIL: Alert not found in Database.")
        sys.exit(1)

    print("DONE: Enterprise Integration verified successfully.")

if __name__ == "__main__":
    test_enterprise_integration()
