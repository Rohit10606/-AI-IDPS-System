import time
import os
import threading
from src.config import settings

def watch_alerts(stop_event, results):
    last_pos = 0
    if os.path.exists(settings.ALERT_LOG_PATH):
        last_pos = os.path.getsize(settings.ALERT_LOG_PATH)
        
    while not stop_event.is_set():
        if os.path.exists(settings.ALERT_LOG_PATH):
            with open(settings.ALERT_LOG_PATH, 'r') as f:
                f.seek(last_pos)
                line = f.readline()
                if line:
                    results.append(time.time())
                    last_pos = f.tell()
        time.sleep(0.01) # High frequency check for accuracy

def run_performance_bench():
    print("--- IDPS PERFORMANCE BENCHMARK ---")
    
    # 1. Latency Test
    results = []
    stop_event = threading.Event()
    watcher = threading.Thread(target=watch_alerts, args=(stop_event, results))
    watcher.start()

    print("Measuring single-entry latency...")
    start_time = time.time()
    with open(settings.LOG_FILE_PATH, 'a') as f:
        f.write("Critical security breach signature detected - Perf Test\n")
    
    # Wait for detection
    timeout = 5
    while len(results) == 0 and (time.time() - start_time) < timeout:
        time.sleep(0.05)
    
    if len(results) > 0:
        latency = results[0] - start_time
        print(f"[LATENCY] {latency:.4f} seconds")
    else:
        print("[ERROR] Latency test timed out (No detection).")

    # 2. Throughput Stress Test
    print("\nMeasuring stress throughput (100 logs)...")
    batch_start = time.time()
    with open(settings.LOG_FILE_PATH, 'a') as f:
        for i in range(100):
            f.write(f"Stress test log entry {i} - Timestamp={time.time()}\n")
    batch_end = time.time()
    
    duration = batch_end - batch_start
    print(f"[THROUGHPUT] Injected 100 logs in {duration:.4f} seconds.")
    print(f"[SPEED] {100/duration:.2f} logs/sec system injection rate.")

    stop_event.set()
    watcher.join()

if __name__ == "__main__":
    run_performance_bench()
