import time
import os
import threading
import random
import psutil
from concurrent.futures import ThreadPoolExecutor
from src.config import settings

# --- Configuration ---
LOG_FILE = settings.LOG_FILE_PATH
NUM_THREADS = 10
LOGS_PER_THREAD = 500  # Total 5,000 logs
BATCH_SIZE = 100

def get_system_stats():
    """Returns a snapshot of current system resource usage."""
    cpu = psutil.cpu_percent(interval=None)
    memory = psutil.virtual_memory().percent
    return cpu, memory

def concurrent_injector(thread_id):
    """Worker function for high-speed log injection."""
    count = 0
    while count < LOGS_PER_THREAD:
        # Mix of Normal and Attack traffic
        if random.random() > 0.9:
            log = f"Failed login attempt from 192.168.1.{random.randint(2, 254)} - THREAD_{thread_id}_{count}"
        else:
            log = f"Normal heartbeat check from node_{thread_id} - Sequence {count}"
        
        with open(LOG_FILE, 'a') as f:
            f.write(f"{log}\n")
            
        count += 1
        if count % BATCH_SIZE == 0:
            time.sleep(0.01) # Tiny yield to allow I/O to breathe

def resource_monitor(stop_event, stats_list):
    """Background thread to monitor system resources."""
    while not stop_event.is_set():
        stats_list.append(get_system_stats())
        time.sleep(0.5)

def run_extreme_test():
    print("="*50)
    print("   EXTREME IDPS STRESS TEST (5,000 LOGS)   ")
    print("="*50)
    
    # 1. Preparation
    if os.path.exists(LOG_FILE):
        os.remove(LOG_FILE)
    
    stats_list = []
    stop_event = threading.Event()
    monitor_thread = threading.Thread(target=resource_monitor, args=(stop_event, stats_list))
    
    # 2. Start Monitoring
    monitor_thread.start()
    
    print(f"Starting {NUM_THREADS} injection threads...")
    start_time = time.time()
    
    # 3. High-Speed Injection
    with ThreadPoolExecutor(max_workers=NUM_THREADS) as executor:
        for i in range(NUM_THREADS):
            executor.submit(concurrent_injector, i)
            
    end_time = time.time()
    
    # 4. Cleanup & Metrics
    stop_event.set()
    monitor_thread.join()
    
    total_time = end_time - start_time
    avg_cpu = sum(s[0] for s in stats_list) / len(stats_list) if stats_list else 0
    max_mem = max(s[1] for s in stats_list) if stats_list else 0
    
    print("\n" + "="*50)
    print("   STRESS TEST RESULTS   ")
    print("="*50)
    print(f"Total Logs Injected: 5,000")
    print(f"Execution Time:      {total_time:.2f} seconds")
    print(f"Throughput:          {5000/total_time:.2f} logs/second")
    print(f"Avg CPU Usage:       {avg_cpu:.1f}%")
    print(f"Peak Memory Usage:    {max_mem:.1f}%")
    print("="*50)
    
    print("\nChecking IDPS Response Stability...")
    # Give the IDPS a moment to finish processing the queue
    time.sleep(5)
    
    if os.path.exists(settings.ALERT_LOG_PATH):
        with open(settings.ALERT_LOG_PATH, 'r') as f:
            alert_count = len(f.readlines())
        print(f"Threats Detected:    {alert_count}")
    
    print("\n[CONCLUSION] If system did not crash, IDPS is STABLE under load.")

if __name__ == "__main__":
    run_extreme_test()
