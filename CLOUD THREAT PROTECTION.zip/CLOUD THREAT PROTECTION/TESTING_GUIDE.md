# IDPS Manual Testing Guide

Follow these steps to manually verify the IDPS functionality.

## 1. Start the IDPS
Open a terminal and run:
```powershell
# Ensure UTF-8 for Thai characters
$env:PYTHONUTF8=1
& "C:\Users\ROHIT KUMAR\AppData\Local\Programs\Python\Python312\python.exe" src/main.py
```

## 2. Open Testing Terminal
Open a **second terminal** and run the manual injector:
```powershell
$env:PYTHONUTF8=1
& "C:\Users\ROHIT KUMAR\AppData\Local\Programs\Python\Python312\python.exe" manual_inject.py
```

## 3. Test Scenarios

### Scenario A: Baseline (Normal Traffic)
- **Input**: Choice `1` in `manual_inject.py`.
- **Log**: `User accessed homepage /index.html from 192.168.1.5`
- **Expectation**: IDPS console shows no alerts. `logs/alerts.log` remains unchanged.

### Scenario B: Signature Match (Known Attack)
- **Input**: Choice `2` in `manual_inject.py`.
- **Log**: `Failed login attempt for user 'admin' from 10.0.0.50`
- **Expectation**: IDPS console displays a `!!! [SIGNATURE MATCH]` alert from `Rule-Engine`.

### Scenario C: High-Risk Access (Logic)
- **Input**: Choice `3` in `manual_inject.py`.
- **Log**: `Unauthorized access detected on confidential /api/admin`
- **Expectation**: IDPS console displays a `!!! [SIGNATURE MATCH]` or `[ANOMALY DETECTED]` alert.

### Scenario D: Zero-Day / Anomaly (AI Detection)
- **Input**: Choice `4` in `manual_inject.py`.
- **Log**: A 200+ character high-entropy string.
- **Expectation**: IDPS console displays a `!!! [ANOMALY DETECTED]` alert from `AI-Engine`.

## 4. Verification Files
- **System Logs**: `logs/system.log` (Injection target)
- **Alert Logs**: `logs/alerts.log` (Detection results)
- **Action Logs**: `logs/IDPS-HARDENED.log` (Full audit trail)
