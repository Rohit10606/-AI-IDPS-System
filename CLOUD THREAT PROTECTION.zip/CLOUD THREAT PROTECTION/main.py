import time
from src.utils.logger import setup_logger
from src.detector.ai_engine import AIEngine
from src.detector.rules_engine import RulesEngine
from src.response.action.py import Responder # Wait, the file is action.py not responder.py. Let me check.
# Correction: src.response.action

from src.response.action import Responder
from src.processor.preprocessor import TrafficPreprocessor

def main():
    # 1. Setup Logging
    logger = setup_logger('IDPS', 'logs/system.log')
    logger.info("Autonomous IDPS Started...")

    # 2. Initialize Engines
    ai_engine = AIEngine()
    rules_engine = RulesEngine()
    responder = Responder(logger)
    preprocessor = TrafficPreprocessor()

    # 3. Simulated Traffic Loop
    try:
        while True:
            # Mock incoming network packet
            packet = {
                "source_ip": "192.168.1.50",
                "port": 80,
                "payload_size": 1024,
                "flags": "SYN"
            }

            # --- Step A: Rule-Based Check ---
            is_rule_violation, reason = rules_engine.check_rules(packet)
            if is_rule_violation:
                logger.warning(f"Rule Violation Detected: {reason}")
                responder.execute_action("Signature Match", packet)
            
            # --- Step B: AI-Based Check ---
            # Mock feature vector extraction
            features = [0, 1] 
            prediction = ai_engine.predict(features)
            
            if prediction == 1:
                logger.warning("AI Engine detected anomalous behavior!")
                responder.execute_action("Anomaly Detected", packet)

            time.sleep(5) # Scan every 5 seconds
            
    except KeyboardInterrupt:
        logger.info("IDPS Shutting down...")

if __name__ == "__main__":
    main()
