# Autonomous Cloud-Native AI IDPS

A beginner-friendly Intrusion Detection and Prevention System (IDPS) using scikit-learn and Python.

## Project Structure
- `src/`: Main source code.
    - `detector/`: AI and Rule-based detection engines.
    - `processor/`: Data cleaning and feature extraction.
    - `response/`: Automated mitigation actions.
    - `utils/`: Logging and helper functions.
- `train_model.py`: Script to train the AI model.
- `main.py`: Main entry point to run the IDPS system.
- `data/`: Store datasets here.
- `models/`: Store trained models here.
- `logs/`: Check here for detected threats and system logs.

## Getting Started
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Train the model (requires data in `data/`):
   ```bash
   python train_model.py
   ```
3. Run the IDPS:
   ```bash
   python main.py
   ```

## Features
- AI-based Anomaly Detection (scikit-learn)
- Signature-based Rule Engine
- Automated Response Actions (Blocking/Alerting)
- Centralized Logging
