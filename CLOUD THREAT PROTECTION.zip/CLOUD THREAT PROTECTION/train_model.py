import pandas as pd
import json
import joblib
import os
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from src.config import settings
from src.processor.feature_engineer import FeatureEngineer

def train():
    """
    Trains a production-grade Isolation Forest pipeline with consistent feature names.
    """
    print("--- PRODUCTION PIPELINE TRAINING STARTING ---")
    
    if not os.path.exists(settings.DATA_PATH):
        print(f"Error: {settings.DATA_PATH} not found. Generate data first.")
        return

    # 1. Load Data
    df = pd.read_csv(settings.DATA_PATH)
    
    # 2. Sync Features using the central FeatureEngineer
    feature_cols = FeatureEngineer.get_feature_names()
    X = df[feature_cols]

    # 3. Build Unified Pipeline (Scaler + Model)
    # This ensures scaling is always consistent with training during inference
    pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("model", IsolationForest(
            n_estimators=200,
            contamination=settings.CONTAMINATION,
            random_state=settings.RANDOM_STATE,
            bootstrap=True
        ))
    ])

    print(f"Fitting pipeline on {len(X)} samples...")
    pipeline.fit(X)

    # 4. Persistence
    os.makedirs(os.path.dirname(settings.PIPELINE_PATH), exist_ok=True)
    
    # Save Feature Names (Used for reindexing during inference)
    with open(settings.FEATURE_NAMES_PATH, 'w') as f:
        json.dump(list(X.columns), f)
    
    # Save Consolidated Pipeline
    joblib.dump(pipeline, settings.PIPELINE_PATH)
    
    # Also save to old MODEL_PATH for backward compatibility with older components if needed
    joblib.dump({'model': pipeline.named_steps['model'], 'scaler': pipeline.named_steps['scaler']}, settings.MODEL_PATH)
    
    print(f"[SUCCESS] Pipeline saved at: {os.path.basename(settings.PIPELINE_PATH)}")
    print(f"[SUCCESS] Feature names saved at: {os.path.basename(settings.FEATURE_NAMES_PATH)}")

if __name__ == "__main__":
    train()
