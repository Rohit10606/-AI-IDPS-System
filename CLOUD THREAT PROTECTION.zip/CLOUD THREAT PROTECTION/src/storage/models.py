from sqlalchemy import Column, Integer, String, DateTime, Float
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class Alert(Base):
    """
    SQLAlchemy model for persistent threat storage.
    """
    __tablename__ = 'alerts'

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    threat_type = Column(String(100), nullable=False)
    severity = Column(String(20), nullable=False)
    detected_by = Column(String(50), nullable=False)
    details = Column(String(500))
    ip_address = Column(String(50), nullable=True) # For future network-level integration

    def to_dict(self):
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat(),
            "threat_type": self.threat_type,
            "severity": self.severity,
            "detected_by": self.detected_by,
            "details": self.details,
            "ip_address": self.ip_address
        }
