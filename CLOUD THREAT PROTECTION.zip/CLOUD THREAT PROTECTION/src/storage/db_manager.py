import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from src.config import settings
from src.storage.models import Base, Alert

class DatabaseManager:
    """
    Handles all SQLite interactions for the enterprise IDPS.
    """
    def __init__(self):
        db_path = settings.DATABASE_PATH
        # Ensure data directory exists
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self.engine = create_engine(f"sqlite:///{db_path}")
        self.Session = sessionmaker(bind=self.engine)
        
        # Create tables if they don't exist
        Base.metadata.create_all(self.engine)

    def save_alert(self, threat_type, severity, detected_by, details, ip=None):
        """Persists a threat detection event to the database."""
        session = self.Session()
        try:
            new_alert = Alert(
                threat_type=threat_type,
                severity=severity,
                detected_by=detected_by,
                details=details,
                ip_address=ip
            )
            session.add(new_alert)
            session.commit()
            return new_alert.id
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()

    def get_recent_alerts(self, limit=50):
        """Retrieves the most recent alerts for the API."""
        session = self.Session()
        alerts = session.query(Alert).order_by(Alert.timestamp.desc()).limit(limit).all()
        result = [a.to_dict() for a in alerts]
        session.close()
        return result
