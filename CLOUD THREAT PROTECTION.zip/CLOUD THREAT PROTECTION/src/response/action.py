import subprocess
import os
import platform

class Responder:
    """
    Hardened Intrusion Prevention System (IPS).
    Supports real-world IP blocking via iptables on Linux.
    """
    def __init__(self, logger):
        self.logger = logger
        self.blocked_ips = set()
        # Industry Best Practice: Safelisting internal/management IPs
        self.safelist = ["127.0.0.1", "localhost", "10.0.0.1"]

    def _execute_system_command(self, cmd):
        """Safely execute system commands and log results."""
        try:
            # Check for Linux (iptables requirement)
            if platform.system() != "Linux":
                self.logger.debug(f"Non-Linux system detected. Skipping real command: {' '.join(cmd)}")
                return False
            
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            self.logger.info(f"System command executed: {' '.join(cmd)}")
            return True
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Failed to execute system command: {e.stderr}")
            return False
        except Exception as e:
            self.logger.error(f"Unexpected error during command execution: {str(e)}")
            return False

    def block_ip(self, ip_address):
        """
        Blocks an IP address using Linux iptables.
        """
        if ip_address in self.safelist:
            self.logger.warning(f"Safelisted IP attempted to be blocked: {ip_address}. Policy: Bypass.")
            return False

        if ip_address in self.blocked_ips:
            return False

        self.logger.warning(f"ACTION TRIGGERED: Blocking IP {ip_address}")
        
        # Real iptables command
        cmd = ["sudo", "iptables", "-A", "INPUT", "-s", ip_address, "-j", "DROP"]
        
        success = self._execute_system_command(cmd)
        if success:
            self.blocked_ips.add(ip_address)
            print(f"[IPS] REAL BLOCK SUCCESS: {ip_address}")
            self.logger.info(f"IP {ip_address} successfully added to iptables DROP list.")
        else:
            print(f"[IPS] BLOCK FAILED (Check Permissions): {ip_address}")
            
        return success

    def trigger_mitigation(self, threat_type, log_line):
        """
        Extract IP and execute blocking policy.
        """
        # Improved Extraction (Looking for common IP patterns)
        import re
        ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        matches = re.findall(ip_pattern, log_line)
        
        if matches:
            target_ip = matches[0]
            self.block_ip(target_ip)
            return True
        
        self.logger.warning(f"Mitigation failed: No valid IP found in log line: {log_line[:50]}...")
        return False
