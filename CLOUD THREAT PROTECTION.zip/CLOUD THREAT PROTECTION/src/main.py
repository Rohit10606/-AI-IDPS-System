import os
import time
import queue
import signal
import sys

# --- ROBUST PATH INJECTION ---
# Ensures 'src' module is findable even if run from different directories
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
# -----------------------------

import threading
import uvicorn
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from rich.console import Console
from rich.panel import Panel
from rich.status import Status
from src.config import settings
from src.utils.logger import setup_logger
from src.detector.rules import RuleEngine
from src.detector.ai_engine import AIEngine
from src.monitor.live_monitor import LiveMonitor
from src.notifier.alerter import Alerter
from src.response.action import Responder
from src.service import api 

console = Console()

# --- Startup Helpers ---
def start_api_server(metrics_obj):
    """Function to run FastAPI inside a thread."""
    api.system_metrics = metrics_obj
    uvicorn.run(api.app, host="0.0.0.0", port=8000, log_level="error")

def show_startup_banner():
    console.print(Panel("[bold blue]ENTERPRISE IDPS ENGINE[/]\nStatus: Initializing...", title="System"))

class IDPSMetrics:
    """
    Thread-safe enterprise metrics tracking.
    """
    def __init__(self):
        self.total_logs = 0
        self.threats = 0
        self.anomalies = 0
        self.lock = threading.Lock()

    def record_log(self):
        with self.lock: self.total_logs += 1

    def record_threat(self, is_ai=False):
        with self.lock:
            self.threats += 1
            if is_ai: self.anomalies += 1

    def get_snapshot(self):
        with self.lock:
            return {
                "total_processed": self.total_logs,
                "threats_detected": self.threats,
                "anomalies_detected": self.anomalies
            }

def health_check_loop(logger, metrics):
    """Periodic health heartbeat for SIEM monitoring."""
    while True:
        stats = metrics.get_snapshot()
        logger.info("System Health Heartbeat", extra={"event_data": {"status": "HEALTHY", "metrics": stats}})
        time.sleep(60)

def detection_worker(line_queue, detector_logic, metrics):
    """
    Asynchronous worker for parallel log processing with latency tracking.
    """
    rules, ai_engine, alerter, responder, logger = detector_logic
    
    while True:
        try:
            log_line = line_queue.get(timeout=2)
            if log_line is None: break 
            
            start_time = time.perf_counter()
            metrics.record_log()
            
            # 1. Rule Engine (Sanitized Check)
            is_rule_threat, reason = rules.check_log(log_line)
            if is_rule_threat:
                metrics.record_threat()
                severity = "CRITICAL" if "Unauthorized" in reason else "HIGH"
                alerter.send_alert("Signature Match", "Rule-Engine", f"{reason} | Log: {log_line}", severity=severity)
                responder.trigger_mitigation("Rule Breach", log_line)
                line_queue.task_done()
                continue
            
            # 2. AI Engine
            is_ai_threat, score = ai_engine.predict(log_line)
            if is_ai_threat:
                metrics.record_threat(is_ai=True)
                details = f"Anomaly Score: {score:.2f} | Log: {log_line}"
                alerter.send_alert("Anomaly Detected", "AI-Engine", details, severity="CRITICAL")
                responder.trigger_mitigation("ML Inference", log_line)
            
            latency = (time.perf_counter() - start_time) * 1000
            if latency > 100: # Log slow detections
                logger.warning(f"High Latency Detection: {latency:.2f}ms", extra={"event_data": {"latency_ms": latency}})
                
            line_queue.task_done()
        except queue.Empty:
            continue
        except Exception as e:
            logger.error(f"Worker Exception: {str(e)}")

def main():
    show_startup_banner()
    logger = setup_logger('IDPS-ENTERPRISE', settings.IDPS_LOG_PATH)
    metrics = IDPSMetrics()
    
    # Shared Resources
    line_queue = queue.Queue(maxsize=5000) 
    alerter = Alerter(logger)
    responder = Responder(logger)
    rules = RuleEngine(logger)
    ai_engine = AIEngine(logger)
    monitor = LiveMonitor(settings.LOG_FILE_PATH, logger)

    # 1. Start Health Monitoring
    health_thread = threading.Thread(target=health_check_loop, args=(logger, metrics), daemon=True)
    health_thread.start()

    # 2. Start REST API Service
    api_thread = threading.Thread(target=start_api_server, args=(metrics,), daemon=True)
    api_thread.start()
    logger.info("REST API Service started on http://0.0.0.0:8000")

    # 3. Dynamic Scaling (CPU-based)
    num_workers = (os.cpu_count() or 4) * 2
    logger.info(f"Scaling engine to {num_workers} parallel workers.")
    
    executor = ThreadPoolExecutor(max_workers=num_workers + 1)
    worker_logic = (rules, ai_engine, alerter, responder, logger)

    with Status("[bold green]Deploying Defender Nodes...", console=console) as status:
        for _ in range(num_workers):
            executor.submit(detection_worker, line_queue, worker_logic, metrics)
        time.sleep(1)
        status.update("[bold cyan]Activating Enterprise Telemetry...")

    console.print(f"[bold green]▶ Enterprise Defense Online.[/] Scaling: {num_workers} Workers | Buffer: 5000\n")

    # Tracking model version for auto-reload
    last_reload_time = os.path.getmtime(settings.PIPELINE_PATH) if os.path.exists(settings.PIPELINE_PATH) else 0

    try:
        while True:
            # Auto-Reload Check
            if os.path.exists(settings.PIPELINE_PATH):
                mtime = os.path.getmtime(settings.PIPELINE_PATH)
                if mtime > last_reload_time:
                    logger.info("New ML model detected. Hot-reloading AI engine...")
                    ai_engine._load_pipeline()
                    last_reload_time = mtime

            new_logs = monitor.get_new_logs()
            for line in new_logs:
                try:
                    line_queue.put(line, block=False)
                except queue.Full:
                    logger.error("SYSTEM SATURATION: Log buffer overflow. Dropping telemetry.")
            
            time.sleep(settings.SCAN_INTERVAL_SECONDS)
            
    except KeyboardInterrupt:
        console.print("\n[bold yellow]⚠ Enterprise Shutdown signal received.[/]")
        for _ in range(num_workers): line_queue.put(None)
    finally:
        executor.shutdown(wait=True)
        console.print("[bold red]■ System Offline. Session Metrics Exported.[/]")

if __name__ == "__main__":
    main()
