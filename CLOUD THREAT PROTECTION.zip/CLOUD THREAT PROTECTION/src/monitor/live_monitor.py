import time
import os
from src.config import settings

class LiveMonitor:
    """
    Simulates real-time log tailing.
    Reads only new entries added to system.log since the last check.
    """
    def __init__(self, log_path, logger):
        self.log_path = log_path
        self.logger = logger
        self.last_position = 0
        
        # Ensure log file exists
        if not os.path.exists(self.log_path):
            os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
            with open(self.log_path, 'w') as f:
                f.write("# IDPS SYSTEM LOG START\n")
        
        # Start at the end of the file to avoid processing historical noise
        self.last_position = os.path.getsize(self.log_path)

    def get_new_logs(self):
        """
        Yields new lines added to the log file since the last call.
        """
        if not os.path.exists(self.log_path):
            return []

        current_size = os.path.getsize(self.log_path)
        if current_size < self.last_position:
            self.logger.info("Log file truncated. Resetting monitor position.")
            self.last_position = 0

        new_lines = []
        with open(self.log_path, 'r') as f:
            f.seek(self.last_position)
            new_lines = f.readlines()
            self.last_position = f.tell()
            
        return [line.strip() for line in new_lines if line.strip()]
