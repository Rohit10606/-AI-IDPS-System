import os

# Base Directory
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Path Settings
LOG_FILE_PATH = os.path.join(BASE_DIR, 'logs', 'system.log')
ALERT_LOG_PATH = os.path.join(BASE_DIR, 'logs', 'alerts.log')
IDPS_LOG_PATH = os.path.join(BASE_DIR, 'logs', 'idps_internal.log')
MODEL_PATH = os.path.join(BASE_DIR, 'models', 'idps_model.joblib')
PIPELINE_PATH = os.path.join(BASE_DIR, 'models', 'idps_pipeline.joblib')
FEATURE_NAMES_PATH = os.path.join(BASE_DIR, 'models', 'feature_names.json')
DATA_PATH = os.path.join(BASE_DIR, 'data', 'traffic_data.csv')
DATABASE_PATH = os.path.join(BASE_DIR, 'data', 'idps.db')

# Enterprise Integration Settings
WEBHOOK_URL = os.getenv('IDPS_WEBHOOK_URL', 'http://localhost:8080/webhook-test')
IDPS_API_KEY = os.getenv('IDPS_API_KEY', 'DEV-SECRET-KEY-12345')

# ELK Stack (Elasticsearch) Settings
# Support for both 7.x (unauthenticated) and 8.x (authenticated)
ELK_HOST = os.getenv('ELK_HOST', 'http://localhost:9200')
ELK_INDEX = os.getenv('ELK_INDEX', 'idps-alerts')
ELK_API_KEY = os.getenv('ELK_API_KEY', None) # For ES 8.x
ELK_USER = os.getenv('ELK_USER', None)
ELK_PASS = os.getenv('ELK_PASS', None)
ELK_VERIFY_CERTS = os.getenv('ELK_VERIFY_CERTS', 'false').lower() == 'true'

# Detection Settings
RISK_KEYWORDS = ['failed', 'unauthorized', 'error', 'attack', 'malicious']
SCAN_INTERVAL_SECONDS = 2

# Model Settings
RANDOM_STATE = 42
TEST_SIZE = 0.2
CONTAMINATION = 0.1 # Expected percentage of anomalies in the dataset
