from fastapi import FastAPI, HTTPException, Security, Depends
from fastapi.security.api_key import APIKeyHeader
from fastapi.middleware.cors import CORSMiddleware
from starlette.status import HTTP_403_FORBIDDEN
from src.config import settings
from src.storage.db_manager import DatabaseManager
import time

app = FastAPI(title="Enterprise IDPS API", version="1.0.0")
db = DatabaseManager()

# Security Config
API_KEY_NAME = "X-IDPS-KEY"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

# Shared Metrics Reference (Will be injected by main process)
system_metrics = None

async def get_api_key(api_key: str = Depends(api_key_header)):
    if api_key == settings.IDPS_API_KEY:
        return api_key
    raise HTTPException(
        status_code=HTTP_403_FORBIDDEN, detail="Could not validate credentials"
    )

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/status")
async def health_check():
    return {
        "status": "online",
        "timestamp": time.time(),
        "service": "Enterprise-IDPS-Core"
    }

@app.get("/metrics", dependencies=[Depends(get_api_key)])
async def get_metrics():
    if system_metrics:
        return system_metrics.get_snapshot()
    
    # Fallback to Database metrics
    alerts = db.get_recent_alerts(limit=1)
    return {
        "info": "Engine metrics unavailable (API running standalone)",
        "db_records_present": len(alerts) > 0
    }

@app.get("/alerts", dependencies=[Depends(get_api_key)])
async def get_alerts(limit: int = 20):
    try:
        return db.get_recent_alerts(limit=limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
