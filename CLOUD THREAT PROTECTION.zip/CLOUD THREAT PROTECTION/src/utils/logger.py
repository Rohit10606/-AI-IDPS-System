import logging
import os
import json
from datetime import datetime
from src.config import settings

class JSONFormatter(logging.Formatter):
    """
    Custom formatter to output logs in JSON format.
    """
    def format(self, record):
        log_entry = {
            "timestamp": datetime.fromtimestamp(record.created).isoformat(),
            "level": record.levelname,
            "component": record.name,
            "message": record.getMessage(),
        }
        
        # Add extra fields if they exist
        if hasattr(record, "event_data"):
            log_entry["event_data"] = record.event_data
            
        return json.dumps(log_entry)

def setup_logger(name, log_file, level=logging.INFO, json_format=True):
    """
    Standardized logger for the IDPS project.
    """
    os.makedirs(os.path.dirname(log_file), exist_ok=True)

    if json_format:
        formatter = JSONFormatter()
    else:
        formatter = logging.Formatter(
            '[%(asctime)s] [%(name)s] [%(levelname)s] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    handler = logging.FileHandler(log_file)
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    if not logger.handlers:
        logger.addHandler(handler)
        
        # Console output remains human-readable for developer experience
        console_handler = logging.StreamHandler()
        console_formatter = logging.Formatter(
            '[bold cyan]%(name)s[/] [%(levelname)s] %(message)s',
            datefmt='%H:%M:%S'
        )
        # Note: Console formatter will be enhanced by Rich in main.py
        console_handler.setFormatter(logging.Formatter('[%(name)s] [%(levelname)s] %(message)s'))
        logger.addHandler(console_handler)

    return logger
