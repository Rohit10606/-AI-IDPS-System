import re
import math
from src.config import settings

class FeatureEngineer:
    """
    Advanced security-centric feature engineering for IDPS.
    """
    @staticmethod
    def calculate_entropy(text):
        """Calculates Shannon entropy of a string (measures randomness)."""
        if not text or not isinstance(text, str):
            return 0
        prob = [float(text.count(c)) / len(text) for c in dict.fromkeys(list(text))]
        entropy = - sum([p * math.log(p) / math.log(2.0) for p in prob])
        return entropy

    @staticmethod
    def extract_features(log_line):
        """
        Production-ready feature extraction.
        Returns a dictionary of features with fixed keys.
        """
        # Validation: Ensure it's a string
        if not isinstance(log_line, str):
            log_line = str(log_line) if log_line else ""
            
        log_line_lower = log_line.lower()
        length = len(log_line)
        
        # 1. Basic length and randomness
        entropy = FeatureEngineer.calculate_entropy(log_line)
        
        # 2. Security Keywords (Boolean indicators)
        failed = 1 if 'failed' in log_line_lower else 0
        unauthorized = 1 if 'unauthorized' in log_line_lower else 0
        attack = 1 if any(w in log_line_lower for w in ['attack', 'exploit', 'sql', 'injection', 'bypass']) else 0
        
        # 3. Content Density
        digits = sum(c.isdigit() for c in log_line)
        digit_density = digits / length if length > 0 else 0
        
        special_chars = len(re.findall(r'[^a-zA-Z0-9\s]', log_line))
        special_density = special_chars / length if length > 0 else 0

        # Unified Feature Set
        return {
            'length': length,
            'entropy': entropy,
            'failed': failed,
            'unauthorized': unauthorized,
            'attack': attack,
            'num_digits': digits,
            'num_special': special_chars,
            'digit_density': digit_density,
            'special_density': special_density
        }

    @staticmethod
    def get_feature_names():
        """Returns the source of truth for feature column ordering."""
        return ['length', 'entropy', 'failed', 'unauthorized', 'attack', 'num_digits', 'num_special', 'digit_density', 'special_density']
