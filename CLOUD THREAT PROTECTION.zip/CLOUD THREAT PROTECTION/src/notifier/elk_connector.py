import time
from elasticsearch import Elasticsearch
from src.config import settings

class ELKConnector:
    """
    Robust Elasticsearch connector supporting 7.x (None/Basic Auth) 
    and 8.x (API Key/Service Token) protocols.
    """
    def __init__(self, logger):
        self.logger = logger
        self.host = settings.ELK_HOST
        self.index = settings.ELK_INDEX
        self.client = None
        self._connect()

    def _connect(self):
        """
        Dynamically configures the client based on provided credentials.
        Supports: Unauthenticated, Basic Auth (User/Pass), and API Key (8.x).
        """
        try:
            connection_params = {
                "hosts": [self.host],
                "verify_certs": settings.ELK_VERIFY_CERTS,
            }

            # 1. API Key Auth (Preferred for 8.x)
            if settings.ELK_API_KEY:
                connection_params["api_key"] = settings.ELK_API_KEY
                self.logger.info(f"ELK: Initializing with API Key authentication.")
            
            # 2. Basic Auth (7.x / 8.x fallback)
            elif settings.ELK_USER and settings.ELK_PASS:
                connection_params["basic_auth"] = (settings.ELK_USER, settings.ELK_PASS)
                self.logger.info(f"ELK: Initializing with Basic Auth (User/Pass).")
            
            # 3. Unauthenticated (Legacy 7.x)
            else:
                self.logger.info(f"ELK: Initializing in Legacy Mode (Unauthenticated).")

            self.client = Elasticsearch(**connection_params)
            
            # Verify connectivity (ping)
            if self.client.ping():
                self.logger.info(f"ELK: Successfully connected to {self.host}")
                self._ensure_index()
            else:
                self.logger.warning(f"ELK: Connection to {self.host} failed (Ping Timeout).")

        except Exception as e:
            self.logger.error(f"ELK: Initialization error: {str(e)}")

    def _ensure_index(self):
        """Creates the idps-alerts index if it doesn't already exist."""
        try:
            if not self.client.indices.exists(index=self.index):
                self.client.indices.create(index=self.index)
                self.logger.info(f"ELK: Created new index '{self.index}'")
        except Exception as e:
            self.logger.error(f"ELK: Index creation failed: {str(e)}")

    def index_alert(self, alert_data):
        """Indexes an alert document into Elasticsearch with retry logic."""
        if not self.client:
            return
        
        # Fault Tolerance: Simple retry with exponential backoff could be added here
        try:
            response = self.client.index(index=self.index, document=alert_data)
            return response
        except Exception as e:
            self.logger.warning(f"ELK: Failed to index alert: {str(e)}")
            # Optional: Attempt reconnection on failure
            if "Connection" in str(e) or "Timeout" in str(e):
                self._connect()
