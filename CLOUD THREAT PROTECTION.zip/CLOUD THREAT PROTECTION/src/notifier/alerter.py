import threading
import requests
import json
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from src.config import settings
from src.storage.db_manager import DatabaseManager
from src.notifier.elk_connector import ELKConnector

class Alerter:
    """
    Enterprise-Grade Alert System with DB persistence, Webhooks, and ELK Stack support.
    """
    SEVERITY_COLORS = {
        "LOW": "blue",
        "MEDIUM": "yellow",
        "HIGH": "orange3",
        "CRITICAL": "red"
    }

    def __init__(self, logger):
        self.logger = logger
        self.alert_log = settings.ALERT_LOG_PATH
        self.console = Console()
        self.lock = threading.Lock() 
        self.db = DatabaseManager()
        self.webhook_url = settings.WEBHOOK_URL
        self.elk = ELKConnector(logger)

    def send_alert(self, threat_type, detected_by, details, severity="HIGH"):
        """
        Formats, persists, and triggers external notifications for a threat.
        """
        severity = severity.upper()
        color = self.SEVERITY_COLORS.get(severity, "white")
        timestamp = datetime.now().isoformat()

        # 1. Structured JSON Logging
        log_extra = {
            "event_data": {
                "threat_type": threat_type,
                "detected_by": detected_by,
                "severity": severity,
                "details": details,
                "timestamp": timestamp
            }
        }
        self.logger.error(f"ALERT: {threat_type} detected by {detected_by}", extra=log_extra)

        # 2. Database Persistence
        try:
            self.db.save_alert(threat_type, severity, detected_by, details)
        except Exception as e:
            self.logger.error(f"DB Persistence Failed: {str(e)}")

        # 3. Webhook and ELK Triggers (Async-style via background threads)
        threading.Thread(target=self._trigger_webhook, args=(threat_type, severity, details, timestamp), daemon=True).start()
        threading.Thread(target=self._trigger_elk, args=(threat_type, severity, detected_by, details, timestamp), daemon=True).start()

        # 4. Premium Console UI
        table = Table(show_header=False, box=None, padding=(0, 1))
        table.add_row("[bold white]Detections Path:[/]", f"[cyan]{detected_by}[/]")
        table.add_row("[bold white]Incident Details:[/]", f"[white]{details}[/]")
        table.add_row("[bold white]System Status:[/]", f"[bold {color}]Enterprise Defense Active[/]")

        panel = Panel(
            table,
            title=f"[bold {color}]!!! {severity} THREAT DETECTED !!![/]",
            border_style=color,
            expand=False,
            subtitle=f"[italic white]{threat_type}[/]"
        )

        self.console.print("\n")
        self.console.print(panel)

    def _trigger_webhook(self, threat_type, severity, details, timestamp):
        """Sends alert payload to external SIEM/System."""
        if not self.webhook_url: return
        
        payload = {
            "timestamp": timestamp,
            "threat_type": threat_type,
            "severity": severity,
            "details": details,
            "source": "Autonomous-IDPS"
        }
        
        try:
            response = requests.post(self.webhook_url, json=payload, timeout=5)
            if response.status_code >= 400:
                self.logger.warning(f"Webhook rejected with status {response.status_code}")
        except Exception as e:
            self.logger.warning(f"Webhook delivery failed: {str(e)}")

    def _trigger_elk(self, threat_type, severity, detected_by, details, timestamp):
        """Asynchronously pushes the alert payload to Elasticsearch."""
        payload = {
            "@timestamp": timestamp, # Standard ELK timestamp field
            "threat_type": threat_type,
            "severity": severity,
            "detected_by": detected_by,
            "details": details,
            "ip_address": "Internal" # For future implementation
        }
        
        try:
            self.elk.index_alert(payload)
        except Exception as e:
            self.logger.warning(f"ELK Background Indexing failed: {str(e)}")
