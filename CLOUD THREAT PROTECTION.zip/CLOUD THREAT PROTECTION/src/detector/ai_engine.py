import joblib
import os
import json
import pandas as pd
from src.config import settings
from src.processor.feature_engineer import FeatureEngineer

class AIEngine:
    """
    Production-grade AI Engine with integrated Pipeline and feature synchronization.
    """
    def __init__(self, logger):
        self.logger = logger
        self.pipeline_path = settings.PIPELINE_PATH
        self.feature_names_path = settings.FEATURE_NAMES_PATH
        self.pipeline = None
        self.feature_names = []
        self._load_pipeline()

    def _load_pipeline(self):
        """Loads both the sklearn pipeline and the feature names metadata."""
        if os.path.exists(self.pipeline_path) and os.path.exists(self.feature_names_path):
            try:
                # 1. Load Pipeline
                self.pipeline = joblib.load(self.pipeline_path)
                
                # 2. Load Feature Names for consistency
                with open(self.feature_names_path, 'r') as f:
                    self.feature_names = json.load(f)
                
                self.logger.info(f"AI Pipeline loaded successfully with {len(self.feature_names)} features.")
            except Exception as e:
                self.logger.error(f"Critical: Failed to load AI pipeline: {str(e)}")
        else:
            self.logger.warning("AI Pipeline or metadata missing. System will fallback to Rule-Engine.")

    def predict(self, log_line):
        """
        Anomaly detection with guaranteed feature structure and security hardening.
        """
        if not self.pipeline or not self.feature_names:
            return False, 0.0

        try:
            # 0. Security Hardening: Input Sanitization
            # Prevents resource exhaustion from extremely long lines
            if len(log_line) > 5000:
                log_line = log_line[:5000]
                self.logger.warning("Sanitization: Truncated excessively long log line.")
            
            # Remove potentially dangerous control characters
            log_line = "".join(ch for ch in log_line if ch.isprintable())

            # 1. Feature Extraction (Into dictionary)
            features_dict = FeatureEngineer.extract_features(log_line)
            
            # 2. Convert to DataFrame for name consistency
            # Reindexing handles missing features and guarantees column order
            df = pd.DataFrame([features_dict])
            df = df.reindex(columns=self.feature_names, fill_value=0)
            
            # 3. Pipeline Inference (Scaling + Prediction in one step)
            prediction = self.pipeline.predict(df)[0]
            # Decision function provides the raw numeric score
            score = self.pipeline.decision_function(df)[0]

            # IsolationForest returns -1 for outliers
            is_anomaly = True if prediction == -1 else False
            return is_anomaly, score
            
        except Exception as e:
            self.logger.error(f"Inference Failure: {str(e)}")
            return False, 0.0
