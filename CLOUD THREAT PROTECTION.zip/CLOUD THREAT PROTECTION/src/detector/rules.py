from src.config import settings

class RuleEngine:
    """
    Signature-based detection focusing on high-risk keywords.
    """
    def __init__(self, logger):
        self.logger = logger
        self.risk_keywords = settings.RISK_KEYWORDS

    def check_log(self, log_line):
        """
        Scan log line for forbidden combinations.
        """
        log_line_lower = log_line.lower()
        
        # High-risk patterns
        if 'unauthorized' in log_line_lower and 'attack' in log_line_lower:
            return True, "Critical: Unauthorized Attack Pattern"
            
        if 'failed' in log_line_lower and 'admin' in log_line_lower:
            return True, "Suspicious: Failed Admin Login"

        # General keyword match
        for keyword in self.risk_keywords:
            if keyword in log_line_lower:
                return True, f"Rule Match: Found Keyword '{keyword}'"

        return False, None
