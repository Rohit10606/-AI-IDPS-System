import subprocess
import time
import os
import signal

def run_script(name):
    print(f"\n>>> RUNNING: {name}")
    result = subprocess.run(["python", name], capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(f"ERROR in {name}:\n{result.stderr}")

def main():
    print("==========================================")
    print("   IDPS MASTER VALIDATION PIPELINE   ")
    print("==========================================")

    # 1. Cleanup
    log_file = "logs/system.log"
    alert_file = "logs/alerts.log"
    if os.path.exists(log_file): os.remove(log_file)
    if os.path.exists(alert_file): os.remove(alert_file)

    # 2. Initial Setup
    run_script("generate_data.py")
    run_script("train_model.py")

    # 3. Start Main IDPS (Background)
    print("\nStarting IDPS Main Pipeline in background...")
    idps_process = subprocess.Popen(["python", "src/main.py"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(3) # Give it time to initialize

    # 4. Run Test Modules
    run_script("tests/inject_logs.py")
    run_script("tests/performance_test.py")
    run_script("tests/robustness_check.py")
    
    # 5. Final Report
    run_script("tests/validation_report.py")

    # 6. Shutdown IDPS
    print("\nStopping IDPS Main Pipeline...")
    # On Windows, we need to send taskkill or similar if SIGTERM doesn't work
    os.kill(idps_process.pid, signal.SIGTERM)
    
    print("\n==========================================")
    print("   VALIDATION COMPLETE - SEE REPORTS    ")
    print("==========================================")

if __name__ == "__main__":
    main()
