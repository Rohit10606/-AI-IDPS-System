import os
import time
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.status import Status
from rich.table import Table

console = Console()

# Configuration
LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "system.log")

def setup_logs():
    """Ensure the logs directory and system.log exist."""
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'w') as f:
            f.write("# IDPS SYSTEM LOG\n")
        console.print(f"[bold yellow]![/] Initialized missing telemetry file: [cyan]{LOG_FILE}[/]")

def show_header():
    """Displays a premium header for the injection tool."""
    header_text = "[bold blue]🛡️ THREAT INJECTION COMMAND CENTER v1.0[/bold blue]"
    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_row("[cyan]» Interface:[/]", "[white]Manual Telemetry Uplink[/]")
    table.add_row("[cyan]» Target:[/]", f"[white]{LOG_FILE}[/]")
    table.add_row("[cyan]» Status:[/]", "[bold green]LINK ESTABLISHED[/]")

    console.print(Panel(table, title=header_text, border_style="blue", expand=False))
    console.print("[italic gray]Type 'exit' to terminate connection.[/]\n")

def main():
    setup_logs()
    show_header()
    
    try:
        while True:
            # Use Rich Prompt for a better UX
            user_input = Prompt.ask("[bold cyan]INJECT LOG[/]").strip()
            
            if user_input.lower() == 'exit':
                console.print("\n[bold red]✖ Terminating Connection...[/]")
                time.sleep(0.5)
                break
            
            if not user_input:
                continue

            # Simulate backend processing for a premium feel
            with Status("[italic cyan]Uploading to Defensive Matrix...", console=console) as status:
                try:
                    with open(LOG_FILE, 'a') as f:
                        f.write(f"{user_input}\n")
                    time.sleep(0.4) # Brief pause for visual impact
                    status.update("[bold green]✔ LOG INJECTED SUCCESSFULLY")
                    time.sleep(0.2)
                except Exception as e:
                    console.print(f"[bold red]FAIL:[/] {e}")

    except KeyboardInterrupt:
        console.print("\n[bold red]✖ Emergency Shutdown...[/]")

if __name__ == "__main__":
    main()
