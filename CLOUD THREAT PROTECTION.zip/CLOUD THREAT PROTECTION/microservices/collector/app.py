import time
import json
import os
from kafka import KafkaProducer
from microservices.shared.logic import TOPIC_RAW_LOGS

def setup_collector():
    # Kafka configuration (bootstrap server from environment)
    bootstrap_servers = os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
    
    producer = KafkaProducer(
        bootstrap_servers=bootstrap_servers,
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )

    log_path = "/var/log/system.log" # Standardized path for container
    if not os.path.exists(log_path):
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path, 'w') as f:
            f.write("# INITIAL COLLECTOR LOG\n")

    print(f"Collector Service started. Monitoring {log_path}...")
    
    last_position = os.path.getsize(log_path)

    try:
        while True:
            current_size = os.path.getsize(log_path)
            if current_size > last_position:
                with open(log_path, 'r') as f:
                    f.seek(last_position)
                    lines = f.readlines()
                    last_position = f.tell()
                    
                    for line in lines:
                        if line.strip():
                            msg = {
                                "timestamp": time.time(),
                                "log_line": line.strip(),
                                "source": os.getenv('HOSTNAME', 'unknown-host')
                            }
                            producer.send(TOPIC_RAW_LOGS, msg)
                            print(f"[Collector] Sent log: {line.strip()[:50]}...")
            
            time.sleep(1)
    except KeyboardInterrupt:
        print("Collector Service stopping...")
    finally:
        producer.close()

if __name__ == "__main__":
    setup_collector()
