class SharedIDPSLogic:
    """
    Core logic shared across microservices (Collector, Detector, Responder).
    """
    @staticmethod
    def extract_features(log_line):
        log_line = log_line.lower()
        return {
            'length': len(log_line),
            'failed': 1 if 'failed' in log_line else 0,
            'error': 1 if 'error' in log_line else 0,
            'unauthorized': 1 if 'unauthorized' in log_line else 0,
            'attack_word': 1 if any(word in log_line for word in ['attack', 'malicious', 'exploit', 'sql']) else 0
        }

    @staticmethod
    def get_feature_names():
        return ['length', 'failed', 'error', 'unauthorized', 'attack_word']

    @staticmethod
    def log_to_vector(log_line):
        feats = SharedIDPSLogic.extract_features(log_line)
        return [feats[name] for name in SharedIDPSLogic.get_feature_names()]

# Topic naming constants
TOPIC_RAW_LOGS = "idps-raw-logs"
TOPIC_DETECTIONS = "idps-detections"
TOPIC_ALERTS = "idps-alerts"
