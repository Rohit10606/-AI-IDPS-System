from flask import Flask, render_template, jsonify
import json
import threading
from kafka import KafkaConsumer
import os

app = Flask(__name__)

# Global state to store recent detections (for demo purposes)
# In production, this would be stored in a database like Redis or MongoDB
recent_detections = []

def kafka_listener():
    bootstrap_servers = os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
    consumer = KafkaConsumer(
        "idps-detections",
        bootstrap_servers=bootstrap_servers,
        value_deserializer=lambda m: json.loads(m.decode('utf-8'))
    )
    for message in consumer:
        recent_detections.insert(0, message.value)
        if len(recent_detections) > 100:
            recent_detections.pop()

@app.route('/')
def index():
    return "<h1>IDPS Dashboard Active</h1><p>Check /api/detections for live feed.</p>"

@app.route('/api/detections')
def get_detections():
    return jsonify(recent_detections)

if __name__ == "__main__":
    # Start Kafka listener in a background thread
    threading.Thread(target=kafka_listener, daemon=True).start()
    app.run(host='0.0.0.0', port=5000)
