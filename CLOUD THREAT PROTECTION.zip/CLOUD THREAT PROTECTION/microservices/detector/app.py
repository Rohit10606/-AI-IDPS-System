import json
import os
import joblib
from kafka import KafkaConsumer, KafkaProducer
from microservices.shared.logic import SharedIDPSLogic, TOPIC_RAW_LOGS, TOPIC_DETECTIONS

def setup_detector():
    bootstrap_servers = os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
    
    # Consumer for raw logs
    consumer = KafkaConsumer(
        TOPIC_RAW_LOGS,
        bootstrap_servers=bootstrap_servers,
        group_id='detector-group',
        value_deserializer=lambda m: json.loads(m.decode('utf-8'))
    )

    # Producer for detections
    producer = KafkaProducer(
        bootstrap_servers=bootstrap_servers,
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )

    # Load Model (Ensure path is correct in container)
    model_path = os.getenv('MODEL_PATH', '/app/models/idps_model.joblib')
    model = None
    if os.path.exists(model_path):
        model = joblib.load(model_path)
        print(f"Detector Service: AI Model loaded from {model_path}")
    else:
        print("Detector Service: Model not found. Running in Rule-only mode.")

    print("Detector Service started. Listening for logs...")

    for message in consumer:
        log_data = message.value
        log_line = log_data.get('log_line', '')
        
        is_threat = False
        reason = ""
        score = 0.0

        # 1. Rule Check
        if any(word in log_line.lower() for word in ['unauthorized', 'attack', 'failed']):
            is_threat = True
            reason = "Rule-based: High-risk keyword detected"
        
        # 2. AI Check (if model exists)
        if not is_threat and model:
            features = SharedIDPSLogic.log_to_vector(log_line)
            prediction = model.predict([features])[0]
            if prediction == 1:
                is_threat = True
                reason = "AI-based: Anomaly detected"
                score = 0.9 # Mock probability

        if is_threat:
            detection_msg = {
                "timestamp": log_data.get('timestamp'),
                "log_line": log_line,
                "threat_reason": reason,
                "confidence_score": score,
                "source_host": log_data.get('source')
            }
            producer.send(TOPIC_DETECTIONS, detection_msg)
            print(f"[Detector] Threat Detected: {reason}")

if __name__ == "__main__":
    setup_detector()
