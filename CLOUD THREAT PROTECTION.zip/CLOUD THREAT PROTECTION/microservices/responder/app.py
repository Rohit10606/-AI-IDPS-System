import json
import os
import subprocess
from kafka import KafkaConsumer
from microservices.shared.logic import TOPIC_DETECTIONS

def block_ip(ip):
    """
    Simulates real blocking using iptables if running as root.
    Otherwise, just logs the action.
    """
    cmd = ["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"]
    print(f"[Responder] EXECUTING ACTION: Block IP {ip}")
    
    # In a real microservice, we would check permissions
    try:
        # result = subprocess.run(cmd, check=True, capture_output=True)
        # print(f"[Responder] REAL BLOCK SUCCESS: {ip}")
        print(f"[Responder] SIMULATED BLOCK: iptables command logged.")
    except Exception as e:
        print(f"[Responder] BLOCK FAILED: {str(e)}")

def setup_responder():
    bootstrap_servers = os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
    
    consumer = KafkaConsumer(
        TOPIC_DETECTIONS,
        bootstrap_servers=bootstrap_servers,
        group_id='responder-group',
        value_deserializer=lambda m: json.loads(m.decode('utf-8'))
    )

    print("Responder Service started. Listening for detections...")

    for message in consumer:
        detection = message.value
        log_line = detection.get('log_line', '')
        
        # Simple extraction logic for the demo
        # "Failed login attempt from 1.2.3.4"
        if "from" in log_line:
            ip = log_line.split("from")[-1].strip()
            block_ip(ip)
        else:
            print(f"[Responder] Detection received but no IP to block: {log_line[:30]}...")

if __name__ == "__main__":
    setup_responder()
